﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LocalizacaoItemEstoque
{
    public partial class lblConsultar : Form
    {
        public lblConsultar()
        {
            InitializeComponent();
        }

        private void limparCampos()
        {
            //Limpa todos os campos da tela
            txtBoxCodInterno.Clear();
            txtBoxDesc.Clear();
            txtBoxFabricante.Clear();
            comboBoxTipoProd.SelectedIndex = -1;
        }

        private void atualizarGrid()
        {
            //Passa os parâmetros para realizar a conexão com o banco
            MySqlConnectionStringBuilder conexoBD = new MySqlConnectionStringBuilder();
            conexoBD.Server = "localhost";
            conexoBD.Database = "localizacaoestoque";
            conexoBD.UserID = "root";
            conexoBD.Password = "";
            //Realiza a conexão com o banco
            MySqlConnection realizaConexaoBD = new MySqlConnection(conexoBD.ToString());

            try
            {
                realizaConexaoBD.Open();

                //Realiza consulta ao banco de dados de todos os registros da tabela
                MySqlCommand comando = realizaConexaoBD.CreateCommand();
                comando.CommandText = "SELECT * FROM produto";
                MySqlDataReader reader = comando.ExecuteReader();

                dataGridViewConsultar.Rows.Clear();

                //Insere os dados no dataGrid
                while (reader.Read())
                {
                    DataGridViewRow row = (DataGridViewRow)dataGridViewConsultar.Rows[0].Clone();
                    row.Cells[0].Value = reader.GetInt32(0);
                    row.Cells[1].Value = reader.GetInt32(1);
                    row.Cells[2].Value = reader.GetString(2);
                    row.Cells[3].Value = reader.GetString(3);
                    row.Cells[4].Value = reader.GetString(4);
                    row.Cells[5].Value = reader.GetString(5);
                    row.Cells[6].Value = reader.GetString(6);
                    row.Cells[7].Value = reader.GetString(7);
                    row.Cells[8].Value = reader.GetString(8);
                    dataGridViewConsultar.Rows.Add(row);
                }

                realizaConexaoBD.Close();
            }

            catch (Exception ex)
            {
                //Informa que não foi possível realizar a conexão
                MessageBox.Show("Não foi possível realizar conexão");
                Console.WriteLine(ex.Message);
            }
        }

        private void lblConsultar_Load(object sender, EventArgs e)
        {
            atualizarGrid();
        }

        private void btnFiltrar_Click(object sender, EventArgs e)
        {
            atualizarGrid();
        }
    }
}
