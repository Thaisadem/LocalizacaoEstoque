﻿namespace LocalizacaoItemEstoque
{
    partial class lblConsultar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpBoxFiltros = new System.Windows.Forms.GroupBox();
            this.btnFiltrar = new System.Windows.Forms.Button();
            this.txtBoxFabricante = new System.Windows.Forms.TextBox();
            this.lblFabricante = new System.Windows.Forms.Label();
            this.txtBoxCodInterno = new System.Windows.Forms.TextBox();
            this.lblCodInterno = new System.Windows.Forms.Label();
            this.txtBoxDesc = new System.Windows.Forms.TextBox();
            this.lclDescricao = new System.Windows.Forms.Label();
            this.comboBoxTipoProd = new System.Windows.Forms.ComboBox();
            this.lblTipoProduto = new System.Windows.Forms.Label();
            this.txtBoxCod = new System.Windows.Forms.TextBox();
            this.lblCodigo = new System.Windows.Forms.Label();
            this.dataGridViewConsultar = new System.Windows.Forms.DataGridView();
            this.ColumnCodProduto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumncoInterno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumntipoProduto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumndescricaoItem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnprecoVenda = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnprecoCusto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnrazaoSocialFab = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumndescLocalizacaoEst = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnunidadeMedida = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grpBoxFiltros.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewConsultar)).BeginInit();
            this.SuspendLayout();
            // 
            // grpBoxFiltros
            // 
            this.grpBoxFiltros.Controls.Add(this.btnFiltrar);
            this.grpBoxFiltros.Controls.Add(this.txtBoxFabricante);
            this.grpBoxFiltros.Controls.Add(this.lblFabricante);
            this.grpBoxFiltros.Controls.Add(this.txtBoxCodInterno);
            this.grpBoxFiltros.Controls.Add(this.lblCodInterno);
            this.grpBoxFiltros.Controls.Add(this.txtBoxDesc);
            this.grpBoxFiltros.Controls.Add(this.lclDescricao);
            this.grpBoxFiltros.Controls.Add(this.comboBoxTipoProd);
            this.grpBoxFiltros.Controls.Add(this.lblTipoProduto);
            this.grpBoxFiltros.Controls.Add(this.txtBoxCod);
            this.grpBoxFiltros.Controls.Add(this.lblCodigo);
            this.grpBoxFiltros.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxFiltros.Location = new System.Drawing.Point(12, 12);
            this.grpBoxFiltros.Name = "grpBoxFiltros";
            this.grpBoxFiltros.Size = new System.Drawing.Size(538, 114);
            this.grpBoxFiltros.TabIndex = 1;
            this.grpBoxFiltros.TabStop = false;
            this.grpBoxFiltros.Text = "Filtros";
            // 
            // btnFiltrar
            // 
            this.btnFiltrar.Location = new System.Drawing.Point(450, 79);
            this.btnFiltrar.Name = "btnFiltrar";
            this.btnFiltrar.Size = new System.Drawing.Size(75, 23);
            this.btnFiltrar.TabIndex = 10;
            this.btnFiltrar.Text = "Filtrar";
            this.btnFiltrar.UseVisualStyleBackColor = true;
            this.btnFiltrar.Click += new System.EventHandler(this.btnFiltrar_Click);
            // 
            // txtBoxFabricante
            // 
            this.txtBoxFabricante.Location = new System.Drawing.Point(201, 51);
            this.txtBoxFabricante.Name = "txtBoxFabricante";
            this.txtBoxFabricante.Size = new System.Drawing.Size(324, 22);
            this.txtBoxFabricante.TabIndex = 9;
            // 
            // lblFabricante
            // 
            this.lblFabricante.AutoSize = true;
            this.lblFabricante.Location = new System.Drawing.Point(146, 54);
            this.lblFabricante.Name = "lblFabricante";
            this.lblFabricante.Size = new System.Drawing.Size(58, 16);
            this.lblFabricante.TabIndex = 8;
            this.lblFabricante.Text = "Fabricante";
            // 
            // txtBoxCodInterno
            // 
            this.txtBoxCodInterno.Location = new System.Drawing.Point(80, 51);
            this.txtBoxCodInterno.Name = "txtBoxCodInterno";
            this.txtBoxCodInterno.Size = new System.Drawing.Size(50, 22);
            this.txtBoxCodInterno.TabIndex = 7;
            // 
            // lblCodInterno
            // 
            this.lblCodInterno.AutoSize = true;
            this.lblCodInterno.Location = new System.Drawing.Point(6, 54);
            this.lblCodInterno.Name = "lblCodInterno";
            this.lblCodInterno.Size = new System.Drawing.Size(78, 16);
            this.lblCodInterno.TabIndex = 6;
            this.lblCodInterno.Text = "Código Interno";
            // 
            // txtBoxDesc
            // 
            this.txtBoxDesc.Location = new System.Drawing.Point(334, 21);
            this.txtBoxDesc.Name = "txtBoxDesc";
            this.txtBoxDesc.Size = new System.Drawing.Size(191, 22);
            this.txtBoxDesc.TabIndex = 5;
            // 
            // lclDescricao
            // 
            this.lclDescricao.AutoSize = true;
            this.lclDescricao.Location = new System.Drawing.Point(282, 24);
            this.lclDescricao.Name = "lclDescricao";
            this.lclDescricao.Size = new System.Drawing.Size(55, 16);
            this.lclDescricao.TabIndex = 4;
            this.lclDescricao.Text = "Descrição";
            // 
            // comboBoxTipoProd
            // 
            this.comboBoxTipoProd.FormattingEnabled = true;
            this.comboBoxTipoProd.Items.AddRange(new object[] {
            "Arandelas",
            "Abajures",
            "Balizadores",
            "Coluna",
            "Embutida",
            "Pendentes",
            "Plafons",
            "Spots"});
            this.comboBoxTipoProd.Location = new System.Drawing.Point(176, 19);
            this.comboBoxTipoProd.Name = "comboBoxTipoProd";
            this.comboBoxTipoProd.Size = new System.Drawing.Size(91, 24);
            this.comboBoxTipoProd.TabIndex = 3;
            // 
            // lblTipoProduto
            // 
            this.lblTipoProduto.AutoSize = true;
            this.lblTipoProduto.Location = new System.Drawing.Point(110, 24);
            this.lblTipoProduto.Name = "lblTipoProduto";
            this.lblTipoProduto.Size = new System.Drawing.Size(69, 16);
            this.lblTipoProduto.TabIndex = 2;
            this.lblTipoProduto.Text = "Tipo Produto";
            // 
            // txtBoxCod
            // 
            this.txtBoxCod.Location = new System.Drawing.Point(45, 21);
            this.txtBoxCod.Name = "txtBoxCod";
            this.txtBoxCod.Size = new System.Drawing.Size(50, 22);
            this.txtBoxCod.TabIndex = 1;
            // 
            // lblCodigo
            // 
            this.lblCodigo.AutoSize = true;
            this.lblCodigo.Location = new System.Drawing.Point(6, 24);
            this.lblCodigo.Name = "lblCodigo";
            this.lblCodigo.Size = new System.Drawing.Size(42, 16);
            this.lblCodigo.TabIndex = 0;
            this.lblCodigo.Text = "Código";
            // 
            // dataGridViewConsultar
            // 
            this.dataGridViewConsultar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewConsultar.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnCodProduto,
            this.ColumncoInterno,
            this.ColumntipoProduto,
            this.ColumndescricaoItem,
            this.ColumnprecoVenda,
            this.ColumnprecoCusto,
            this.ColumnrazaoSocialFab,
            this.ColumndescLocalizacaoEst,
            this.ColumnunidadeMedida});
            this.dataGridViewConsultar.Location = new System.Drawing.Point(12, 142);
            this.dataGridViewConsultar.Name = "dataGridViewConsultar";
            this.dataGridViewConsultar.Size = new System.Drawing.Size(538, 119);
            this.dataGridViewConsultar.TabIndex = 21;
            // 
            // ColumnCodProduto
            // 
            this.ColumnCodProduto.HeaderText = "Cód. Produto";
            this.ColumnCodProduto.Name = "ColumnCodProduto";
            // 
            // ColumncoInterno
            // 
            this.ColumncoInterno.HeaderText = "Cód. Interno";
            this.ColumncoInterno.Name = "ColumncoInterno";
            // 
            // ColumntipoProduto
            // 
            this.ColumntipoProduto.HeaderText = "Tipo Produto";
            this.ColumntipoProduto.Name = "ColumntipoProduto";
            // 
            // ColumndescricaoItem
            // 
            this.ColumndescricaoItem.HeaderText = "Descrição Item";
            this.ColumndescricaoItem.Name = "ColumndescricaoItem";
            // 
            // ColumnprecoVenda
            // 
            this.ColumnprecoVenda.HeaderText = "Preço Venda";
            this.ColumnprecoVenda.Name = "ColumnprecoVenda";
            // 
            // ColumnprecoCusto
            // 
            this.ColumnprecoCusto.HeaderText = "Preço Custo";
            this.ColumnprecoCusto.Name = "ColumnprecoCusto";
            // 
            // ColumnrazaoSocialFab
            // 
            this.ColumnrazaoSocialFab.HeaderText = "Fabricante";
            this.ColumnrazaoSocialFab.Name = "ColumnrazaoSocialFab";
            // 
            // ColumndescLocalizacaoEst
            // 
            this.ColumndescLocalizacaoEst.HeaderText = "Localização Estoque";
            this.ColumndescLocalizacaoEst.Name = "ColumndescLocalizacaoEst";
            // 
            // ColumnunidadeMedida
            // 
            this.ColumnunidadeMedida.HeaderText = "Unidade Medida";
            this.ColumnunidadeMedida.Name = "ColumnunidadeMedida";
            // 
            // lblConsultar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(572, 508);
            this.Controls.Add(this.dataGridViewConsultar);
            this.Controls.Add(this.grpBoxFiltros);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "lblConsultar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Consultar";
            this.Load += new System.EventHandler(this.lblConsultar_Load);
            this.grpBoxFiltros.ResumeLayout(false);
            this.grpBoxFiltros.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewConsultar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpBoxFiltros;
        private System.Windows.Forms.TextBox txtBoxFabricante;
        private System.Windows.Forms.Label lblFabricante;
        private System.Windows.Forms.TextBox txtBoxCodInterno;
        private System.Windows.Forms.Label lblCodInterno;
        private System.Windows.Forms.TextBox txtBoxDesc;
        private System.Windows.Forms.Label lclDescricao;
        private System.Windows.Forms.ComboBox comboBoxTipoProd;
        private System.Windows.Forms.Label lblTipoProduto;
        private System.Windows.Forms.Label lblCodigo;
        private System.Windows.Forms.Button btnFiltrar;
        private System.Windows.Forms.TextBox txtBoxCod;
        private System.Windows.Forms.DataGridView dataGridViewConsultar;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnCodProduto;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumncoInterno;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumntipoProduto;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumndescricaoItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnprecoVenda;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnprecoCusto;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnrazaoSocialFab;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumndescLocalizacaoEst;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnunidadeMedida;
    }
}