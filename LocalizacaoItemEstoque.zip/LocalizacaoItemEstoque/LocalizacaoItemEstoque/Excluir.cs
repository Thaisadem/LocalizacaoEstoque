﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LocalizacaoItemEstoque
{
    public partial class Excluir : Form
    {
        public Excluir()
        {
            InitializeComponent();
        }

        private void limparCampos()
        {
            //Limpa todos os campos da tela
            txtBoxCodInterno.Clear();
            txtBoxDesc.Clear();
            txtBoxFabricante.Clear();
            txtLocalizacaoEstoque.Clear();
            txtBoxPrecoCusto.Clear();
            txtBoxPrecoVenda.Clear();
            comboBoxTipoProd.SelectedIndex = -1;
            comboBoxUniMed.SelectedIndex = -1;
        }

        private void atualizarGrid()
        {
            //Passa os parâmetros para realizar a conexão com o banco
            MySqlConnectionStringBuilder conexoBD = new MySqlConnectionStringBuilder();
            conexoBD.Server = "localhost";
            conexoBD.Database = "localizacaoestoque";
            conexoBD.UserID = "root";
            conexoBD.Password = "";
            //Realiza a conexão com o banco
            MySqlConnection realizaConexaoBD = new MySqlConnection(conexoBD.ToString());

            try
            {
                realizaConexaoBD.Open();

                //Realiza consulta ao banco de dados de todos os registros da tabela
                MySqlCommand comando = realizaConexaoBD.CreateCommand();
                comando.CommandText = "SELECT * FROM produto";
                MySqlDataReader reader = comando.ExecuteReader();

                dataGridViewExcluir.Rows.Clear();

                //Insere os dados no dataGrid
                while (reader.Read())
                {
                    DataGridViewRow row = (DataGridViewRow)dataGridViewExcluir.Rows[0].Clone();
                    row.Cells[0].Value = reader.GetInt32(0);
                    row.Cells[1].Value = reader.GetInt32(1);
                    row.Cells[2].Value = reader.GetString(2);
                    row.Cells[3].Value = reader.GetString(3);
                    row.Cells[4].Value = reader.GetString(4);
                    row.Cells[5].Value = reader.GetString(5);
                    row.Cells[6].Value = reader.GetString(6);
                    row.Cells[7].Value = reader.GetString(7);
                    row.Cells[8].Value = reader.GetString(8);
                    dataGridViewExcluir.Rows.Add(row);
                }

                realizaConexaoBD.Close();
            }

            catch (Exception ex)
            {
                //Informa que não foi possível realizar a conexão
                MessageBox.Show("Não foi possível realizar conexão");
                Console.WriteLine(ex.Message);
            }
        }

        private void Excluir_Load(object sender, EventArgs e)
        {
            atualizarGrid();
        }

        private void dataGridViewExcluir_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //Insere os dados do dataGridView nos campos para edição
            txtBoxCod.Text = dataGridViewExcluir.Rows[e.RowIndex].Cells["ColumnCodProduto"].FormattedValue.ToString();
            txtBoxCodInterno.Text = dataGridViewExcluir.Rows[e.RowIndex].Cells["ColumncoInterno"].FormattedValue.ToString();
            comboBoxTipoProd.SelectedItem = dataGridViewExcluir.Rows[e.RowIndex].Cells["ColumntipoProduto"].FormattedValue.ToString();
            txtBoxDesc.Text = dataGridViewExcluir.Rows[e.RowIndex].Cells["ColumndescricaoItem"].FormattedValue.ToString();
            txtBoxPrecoVenda.Text = dataGridViewExcluir.Rows[e.RowIndex].Cells["ColumnprecoVenda"].FormattedValue.ToString();
            txtBoxPrecoCusto.Text = dataGridViewExcluir.Rows[e.RowIndex].Cells["ColumnprecoCusto"].FormattedValue.ToString();
            txtBoxFabricante.Text = dataGridViewExcluir.Rows[e.RowIndex].Cells["ColumnrazaoSocialFab"].FormattedValue.ToString();
            txtLocalizacaoEstoque.Text = dataGridViewExcluir.Rows[e.RowIndex].Cells["ColumndescLocalizacaoEst"].FormattedValue.ToString();
            comboBoxUniMed.SelectedItem = dataGridViewExcluir.Rows[e.RowIndex].Cells["ColumnunidadeMedida"].FormattedValue.ToString();
        }

        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexoBD = new MySqlConnectionStringBuilder();
            conexoBD.Server = "localhost";
            conexoBD.Database = "localizacaoestoque";
            conexoBD.UserID = "root";
            conexoBD.Password = "";
            //Realiza a conexão com o banco
            MySqlConnection realizaConexao = new MySqlConnection(conexoBD.ToString());

            try

            {
                realizaConexao.Open();

                //Insere os dados no banco de dados
                MySqlCommand comando = realizaConexao.CreateCommand();
                comando.CommandText = "DELETE FROM produto WHERE codProduto = " + txtBoxCod.Text + "";
                comando.ExecuteNonQuery();

                realizaConexao.Close();
                MessageBox.Show("Deletado com Sucesso!");
                atualizarGrid();
                limparCampos();
            }
            catch (Exception ex)
            {
                //Informa que não foi possível realizar a conexão
                MessageBox.Show("Não foi possível realizar conexão");
                Console.WriteLine(ex.Message);
            }
        }
    }
}
