﻿namespace LocalizacaoItemEstoque
{
    partial class Adicionar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpBoxDadosGerais = new System.Windows.Forms.GroupBox();
            this.txtBoxFabricante = new System.Windows.Forms.TextBox();
            this.lblFabricante = new System.Windows.Forms.Label();
            this.txtBoxCodInterno = new System.Windows.Forms.TextBox();
            this.lblCodInterno = new System.Windows.Forms.Label();
            this.txtBoxDesc = new System.Windows.Forms.TextBox();
            this.lclDescricao = new System.Windows.Forms.Label();
            this.comboBoxTipoProd = new System.Windows.Forms.ComboBox();
            this.lblTipoProduto = new System.Windows.Forms.Label();
            this.txtBoxCod = new System.Windows.Forms.TextBox();
            this.lblCodigo = new System.Windows.Forms.Label();
            this.lblPrecoVenda = new System.Windows.Forms.Label();
            this.txtBoxPrecoVenda = new System.Windows.Forms.TextBox();
            this.lblPrecoCusto = new System.Windows.Forms.Label();
            this.txtBoxPrecoCusto = new System.Windows.Forms.TextBox();
            this.grpBoxDadosVendas = new System.Windows.Forms.GroupBox();
            this.grpBoxDadosEstoque = new System.Windows.Forms.GroupBox();
            this.comboBoxUniMed = new System.Windows.Forms.ComboBox();
            this.lblUnidadeMedida = new System.Windows.Forms.Label();
            this.txtBoxLocalizacaoEstoque = new System.Windows.Forms.TextBox();
            this.lblLocalizacaoEstoque = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.grpBoxDadosGerais.SuspendLayout();
            this.grpBoxDadosVendas.SuspendLayout();
            this.grpBoxDadosEstoque.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpBoxDadosGerais
            // 
            this.grpBoxDadosGerais.Controls.Add(this.txtBoxFabricante);
            this.grpBoxDadosGerais.Controls.Add(this.lblFabricante);
            this.grpBoxDadosGerais.Controls.Add(this.txtBoxCodInterno);
            this.grpBoxDadosGerais.Controls.Add(this.lblCodInterno);
            this.grpBoxDadosGerais.Controls.Add(this.txtBoxDesc);
            this.grpBoxDadosGerais.Controls.Add(this.lclDescricao);
            this.grpBoxDadosGerais.Controls.Add(this.comboBoxTipoProd);
            this.grpBoxDadosGerais.Controls.Add(this.lblTipoProduto);
            this.grpBoxDadosGerais.Controls.Add(this.txtBoxCod);
            this.grpBoxDadosGerais.Controls.Add(this.lblCodigo);
            this.grpBoxDadosGerais.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxDadosGerais.Location = new System.Drawing.Point(12, 12);
            this.grpBoxDadosGerais.Name = "grpBoxDadosGerais";
            this.grpBoxDadosGerais.Size = new System.Drawing.Size(538, 83);
            this.grpBoxDadosGerais.TabIndex = 0;
            this.grpBoxDadosGerais.TabStop = false;
            this.grpBoxDadosGerais.Text = "Dados Gerais";
            // 
            // txtBoxFabricante
            // 
            this.txtBoxFabricante.Location = new System.Drawing.Point(201, 51);
            this.txtBoxFabricante.Name = "txtBoxFabricante";
            this.txtBoxFabricante.Size = new System.Drawing.Size(324, 22);
            this.txtBoxFabricante.TabIndex = 9;
            // 
            // lblFabricante
            // 
            this.lblFabricante.AutoSize = true;
            this.lblFabricante.Location = new System.Drawing.Point(146, 54);
            this.lblFabricante.Name = "lblFabricante";
            this.lblFabricante.Size = new System.Drawing.Size(58, 16);
            this.lblFabricante.TabIndex = 8;
            this.lblFabricante.Text = "Fabricante";
            // 
            // txtBoxCodInterno
            // 
            this.txtBoxCodInterno.Location = new System.Drawing.Point(80, 51);
            this.txtBoxCodInterno.Name = "txtBoxCodInterno";
            this.txtBoxCodInterno.Size = new System.Drawing.Size(50, 22);
            this.txtBoxCodInterno.TabIndex = 7;
            // 
            // lblCodInterno
            // 
            this.lblCodInterno.AutoSize = true;
            this.lblCodInterno.Location = new System.Drawing.Point(6, 54);
            this.lblCodInterno.Name = "lblCodInterno";
            this.lblCodInterno.Size = new System.Drawing.Size(78, 16);
            this.lblCodInterno.TabIndex = 6;
            this.lblCodInterno.Text = "Código Interno";
            // 
            // txtBoxDesc
            // 
            this.txtBoxDesc.Location = new System.Drawing.Point(334, 21);
            this.txtBoxDesc.Name = "txtBoxDesc";
            this.txtBoxDesc.Size = new System.Drawing.Size(191, 22);
            this.txtBoxDesc.TabIndex = 5;
            // 
            // lclDescricao
            // 
            this.lclDescricao.AutoSize = true;
            this.lclDescricao.Location = new System.Drawing.Point(282, 24);
            this.lclDescricao.Name = "lclDescricao";
            this.lclDescricao.Size = new System.Drawing.Size(55, 16);
            this.lclDescricao.TabIndex = 4;
            this.lclDescricao.Text = "Descrição";
            // 
            // comboBoxTipoProd
            // 
            this.comboBoxTipoProd.FormattingEnabled = true;
            this.comboBoxTipoProd.Items.AddRange(new object[] {
            "Arandelas",
            "Abajures",
            "Balizadores",
            "Coluna",
            "Embutida",
            "Pendentes",
            "Plafons",
            "Spots"});
            this.comboBoxTipoProd.Location = new System.Drawing.Point(176, 19);
            this.comboBoxTipoProd.Name = "comboBoxTipoProd";
            this.comboBoxTipoProd.Size = new System.Drawing.Size(91, 24);
            this.comboBoxTipoProd.TabIndex = 3;
            // 
            // lblTipoProduto
            // 
            this.lblTipoProduto.AutoSize = true;
            this.lblTipoProduto.Location = new System.Drawing.Point(110, 24);
            this.lblTipoProduto.Name = "lblTipoProduto";
            this.lblTipoProduto.Size = new System.Drawing.Size(69, 16);
            this.lblTipoProduto.TabIndex = 2;
            this.lblTipoProduto.Text = "Tipo Produto";
            // 
            // txtBoxCod
            // 
            this.txtBoxCod.Enabled = false;
            this.txtBoxCod.Location = new System.Drawing.Point(45, 21);
            this.txtBoxCod.Name = "txtBoxCod";
            this.txtBoxCod.Size = new System.Drawing.Size(50, 22);
            this.txtBoxCod.TabIndex = 1;
            // 
            // lblCodigo
            // 
            this.lblCodigo.AutoSize = true;
            this.lblCodigo.Location = new System.Drawing.Point(6, 24);
            this.lblCodigo.Name = "lblCodigo";
            this.lblCodigo.Size = new System.Drawing.Size(42, 16);
            this.lblCodigo.TabIndex = 0;
            this.lblCodigo.Text = "Código";
            // 
            // lblPrecoVenda
            // 
            this.lblPrecoVenda.AutoSize = true;
            this.lblPrecoVenda.Location = new System.Drawing.Point(6, 24);
            this.lblPrecoVenda.Name = "lblPrecoVenda";
            this.lblPrecoVenda.Size = new System.Drawing.Size(70, 16);
            this.lblPrecoVenda.TabIndex = 0;
            this.lblPrecoVenda.Text = "Preço Venda";
            // 
            // txtBoxPrecoVenda
            // 
            this.txtBoxPrecoVenda.Location = new System.Drawing.Point(72, 21);
            this.txtBoxPrecoVenda.Name = "txtBoxPrecoVenda";
            this.txtBoxPrecoVenda.Size = new System.Drawing.Size(70, 22);
            this.txtBoxPrecoVenda.TabIndex = 1;
            // 
            // lblPrecoCusto
            // 
            this.lblPrecoCusto.AutoSize = true;
            this.lblPrecoCusto.Location = new System.Drawing.Point(151, 24);
            this.lblPrecoCusto.Name = "lblPrecoCusto";
            this.lblPrecoCusto.Size = new System.Drawing.Size(66, 16);
            this.lblPrecoCusto.TabIndex = 6;
            this.lblPrecoCusto.Text = "Preço Custo";
            // 
            // txtBoxPrecoCusto
            // 
            this.txtBoxPrecoCusto.Location = new System.Drawing.Point(214, 21);
            this.txtBoxPrecoCusto.Name = "txtBoxPrecoCusto";
            this.txtBoxPrecoCusto.Size = new System.Drawing.Size(70, 22);
            this.txtBoxPrecoCusto.TabIndex = 7;
            // 
            // grpBoxDadosVendas
            // 
            this.grpBoxDadosVendas.Controls.Add(this.txtBoxPrecoCusto);
            this.grpBoxDadosVendas.Controls.Add(this.lblPrecoCusto);
            this.grpBoxDadosVendas.Controls.Add(this.txtBoxPrecoVenda);
            this.grpBoxDadosVendas.Controls.Add(this.lblPrecoVenda);
            this.grpBoxDadosVendas.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxDadosVendas.Location = new System.Drawing.Point(12, 101);
            this.grpBoxDadosVendas.Name = "grpBoxDadosVendas";
            this.grpBoxDadosVendas.Size = new System.Drawing.Size(538, 56);
            this.grpBoxDadosVendas.TabIndex = 10;
            this.grpBoxDadosVendas.TabStop = false;
            this.grpBoxDadosVendas.Text = "Dados Vendas";
            // 
            // grpBoxDadosEstoque
            // 
            this.grpBoxDadosEstoque.Controls.Add(this.comboBoxUniMed);
            this.grpBoxDadosEstoque.Controls.Add(this.lblUnidadeMedida);
            this.grpBoxDadosEstoque.Controls.Add(this.txtBoxLocalizacaoEstoque);
            this.grpBoxDadosEstoque.Controls.Add(this.lblLocalizacaoEstoque);
            this.grpBoxDadosEstoque.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxDadosEstoque.Location = new System.Drawing.Point(12, 163);
            this.grpBoxDadosEstoque.Name = "grpBoxDadosEstoque";
            this.grpBoxDadosEstoque.Size = new System.Drawing.Size(538, 56);
            this.grpBoxDadosEstoque.TabIndex = 11;
            this.grpBoxDadosEstoque.TabStop = false;
            this.grpBoxDadosEstoque.Text = "Dados Estoque";
            // 
            // comboBoxUniMed
            // 
            this.comboBoxUniMed.FormattingEnabled = true;
            this.comboBoxUniMed.Items.AddRange(new object[] {
            "KIT",
            "UN",
            "PC"});
            this.comboBoxUniMed.Location = new System.Drawing.Point(464, 19);
            this.comboBoxUniMed.Name = "comboBoxUniMed";
            this.comboBoxUniMed.Size = new System.Drawing.Size(61, 24);
            this.comboBoxUniMed.TabIndex = 10;
            // 
            // lblUnidadeMedida
            // 
            this.lblUnidadeMedida.AutoSize = true;
            this.lblUnidadeMedida.Location = new System.Drawing.Point(381, 24);
            this.lblUnidadeMedida.Name = "lblUnidadeMedida";
            this.lblUnidadeMedida.Size = new System.Drawing.Size(86, 16);
            this.lblUnidadeMedida.TabIndex = 6;
            this.lblUnidadeMedida.Text = "Unidade Medida";
            // 
            // txtBoxLocalizacaoEstoque
            // 
            this.txtBoxLocalizacaoEstoque.Location = new System.Drawing.Point(109, 21);
            this.txtBoxLocalizacaoEstoque.Name = "txtBoxLocalizacaoEstoque";
            this.txtBoxLocalizacaoEstoque.Size = new System.Drawing.Size(266, 22);
            this.txtBoxLocalizacaoEstoque.TabIndex = 1;
            // 
            // lblLocalizacaoEstoque
            // 
            this.lblLocalizacaoEstoque.AutoSize = true;
            this.lblLocalizacaoEstoque.Location = new System.Drawing.Point(6, 24);
            this.lblLocalizacaoEstoque.Name = "lblLocalizacaoEstoque";
            this.lblLocalizacaoEstoque.Size = new System.Drawing.Size(104, 16);
            this.lblLocalizacaoEstoque.TabIndex = 0;
            this.lblLocalizacaoEstoque.Text = "Localização Estoque";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(394, 225);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 21;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.Location = new System.Drawing.Point(475, 225);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(75, 23);
            this.btnSalvar.TabIndex = 20;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // Adicionar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(572, 508);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnSalvar);
            this.Controls.Add(this.grpBoxDadosEstoque);
            this.Controls.Add(this.grpBoxDadosVendas);
            this.Controls.Add(this.grpBoxDadosGerais);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Adicionar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Adicionar";
            this.grpBoxDadosGerais.ResumeLayout(false);
            this.grpBoxDadosGerais.PerformLayout();
            this.grpBoxDadosVendas.ResumeLayout(false);
            this.grpBoxDadosVendas.PerformLayout();
            this.grpBoxDadosEstoque.ResumeLayout(false);
            this.grpBoxDadosEstoque.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpBoxDadosGerais;
        private System.Windows.Forms.ComboBox comboBoxTipoProd;
        private System.Windows.Forms.Label lblTipoProduto;
        private System.Windows.Forms.TextBox txtBoxCod;
        private System.Windows.Forms.Label lblCodigo;
        private System.Windows.Forms.Label lclDescricao;
        private System.Windows.Forms.TextBox txtBoxFabricante;
        private System.Windows.Forms.Label lblFabricante;
        private System.Windows.Forms.TextBox txtBoxCodInterno;
        private System.Windows.Forms.Label lblCodInterno;
        private System.Windows.Forms.TextBox txtBoxDesc;
        private System.Windows.Forms.Label lblPrecoVenda;
        private System.Windows.Forms.TextBox txtBoxPrecoVenda;
        private System.Windows.Forms.Label lblPrecoCusto;
        private System.Windows.Forms.TextBox txtBoxPrecoCusto;
        private System.Windows.Forms.GroupBox grpBoxDadosVendas;
        private System.Windows.Forms.GroupBox grpBoxDadosEstoque;
        private System.Windows.Forms.Label lblUnidadeMedida;
        private System.Windows.Forms.TextBox txtBoxLocalizacaoEstoque;
        private System.Windows.Forms.Label lblLocalizacaoEstoque;
        private System.Windows.Forms.ComboBox comboBoxUniMed;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnSalvar;
    }
}