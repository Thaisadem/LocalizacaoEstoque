﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LocalizacaoItemEstoque
{
    public partial class LocalizacaoItemEstoque : Form
    {
        public LocalizacaoItemEstoque()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMaximizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            btnRestaurar.Visible = true;

        }

        private void btnRestaurar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            btnRestaurar.Visible = false;
            btnMaximizar.Visible = true;
        }

        private void AbrirFormNoPanel<Forms>() where Forms : Form, new()
        {
            Form formPanel;
            formPanel = pnlConteudo.Controls.OfType<Forms>().FirstOrDefault();

            if (formPanel == null)
            {
                formPanel = new Forms();
                formPanel.TopLevel = false;
                formPanel.FormBorderStyle = FormBorderStyle.None;
                formPanel.Dock = DockStyle.Fill;
                pnlConteudo.Controls.Add(formPanel);
                pnlConteudo.Tag = formPanel;
                formPanel.Show();
                formPanel.BringToFront();
            }
            else
            {
                if (formPanel.WindowState == FormWindowState.Minimized)
                    formPanel.WindowState = FormWindowState.Normal;
                formPanel.BringToFront();
            }
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            AbrirFormNoPanel<lblConsultar>();
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            AbrirFormNoPanel<Adicionar>();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            AbrirFormNoPanel<Editar>();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            AbrirFormNoPanel<Excluir>();
        }
    }
    }

