﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LocalizacaoItemEstoque
{
    public partial class Adicionar : Form
    {
        public Adicionar()
        {
            InitializeComponent();
        }

        private void limparCampos()
        {
            //Limpa todos os campos da tela
            txtBoxCodInterno.Clear();
            txtBoxDesc.Clear();
            txtBoxFabricante.Clear();
            txtBoxLocalizacaoEstoque.Clear();
            txtBoxPrecoCusto.Clear();
            txtBoxPrecoVenda.Clear();
            comboBoxTipoProd.SelectedIndex = -1;
            comboBoxUniMed.SelectedIndex = -1;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            //Criação da conexão com o banco de dados
            MySqlConnectionStringBuilder conexaoBD = new MySqlConnectionStringBuilder();
            conexaoBD.Server = "localhost";
            conexaoBD.Database = "localizacaoestoque";
            conexaoBD.UserID = "root";
            conexaoBD.Password = "";

            //Realiza conexão com o banco de dados
            MySqlConnection realizaConexaoBD = new MySqlConnection(conexaoBD.ToString());

            try
            {
                realizaConexaoBD.Open();
                MySqlCommand comando = realizaConexaoBD.CreateCommand();

                //Inserir dados na tabela produto
                comando.CommandText = "INSERT INTO produto(codInterno, tipoProduto, descricaoItem, precoVenda, precoCusto, razaoSocialFab, descLocalizacaoEst, unidadeMedida)" +
                    "VALUES('" + txtBoxCodInterno.Text + "', '" + comboBoxTipoProd.SelectedItem + "', '" + txtBoxDesc.Text + "', '"
                    + txtBoxPrecoVenda.Text + "', '" + txtBoxPrecoCusto.Text + "', '" + txtBoxFabricante.Text + "', '"
                    + txtBoxLocalizacaoEstoque.Text + "', '" + comboBoxUniMed.SelectedItem + "');";
                    ;
                comando.ExecuteNonQuery();

                realizaConexaoBD.Close();
                MessageBox.Show("Inserido com Sucesso!");
                limparCampos();
            }

            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {   
            //Ao clicar no botão cancelar limpa os campos
            limparCampos();
        }

    }
}
