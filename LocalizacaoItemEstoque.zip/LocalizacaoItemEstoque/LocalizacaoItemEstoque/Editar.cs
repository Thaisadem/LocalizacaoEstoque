﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LocalizacaoItemEstoque
{
    public partial class Editar : Form
    {
        public Editar()
        {
            InitializeComponent();
        }

        private void limparCampos()
        {
            //Limpa todos os campos da tela
            txtBoxCodInterno.Clear();
            txtBoxDesc.Clear();
            txtBoxFabricante.Clear();
            txtLocalizacaoEstoque.Clear();
            txtBoxPrecoCusto.Clear();
            txtBoxPrecoVenda.Clear();
            comboBoxTipoProd.SelectedIndex = -1;
            comboBoxUniMed.SelectedIndex = -1;
        }

            private void btnSalvar_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexoBD = new MySqlConnectionStringBuilder();
            conexoBD.Server = "localhost";
            conexoBD.Database = "localizacaoestoque";
            conexoBD.UserID = "root";
            conexoBD.Password = "";
            //Realiza a conexão com o banco
            MySqlConnection realizaConexao = new MySqlConnection(conexoBD.ToString());

            try

            {
                realizaConexao.Open();

                //Altera os dados no banco de dados
                MySqlCommand comando = realizaConexao.CreateCommand();
                comando.CommandText = "UPDATE produto SET codInterno = '" + txtBoxCodInterno.Text + "', tipoProduto = '" +
                    comboBoxTipoProd.SelectedItem + "', descricaoItem = '" + txtBoxDesc.Text + "', precoVenda = '" + txtBoxPrecoVenda.Text +
                    "', precoCusto = '" + txtBoxPrecoCusto.Text + "', razaoSocialFab = '" + txtBoxFabricante.Text + "', descLocalizacaoEst = '" +
                    txtLocalizacaoEstoque.Text + "', unidadeMedida = '" + comboBoxUniMed.SelectedItem + "' WHERE codProduto = " + txtBoxCod.Text + "";
                comando.ExecuteNonQuery();
                limparCampos();

                realizaConexao.Close();
                MessageBox.Show("Alterado com Sucesso!");
                atualizarGrid();

            }
            catch (Exception ex)
            {
                //Informa que não foi possível realizar a conexão
                Console.WriteLine(ex.Message);
            }
        }

        private void Editar_Load(object sender, EventArgs e)
        {
            atualizarGrid();
        }

        private void atualizarGrid()
        {
            //Passa os parâmetros para realizar a conexão com o banco
            MySqlConnectionStringBuilder conexoBD = new MySqlConnectionStringBuilder();
            conexoBD.Server = "localhost";
            conexoBD.Database = "localizacaoestoque";
            conexoBD.UserID = "root";
            conexoBD.Password = "";
            //Realiza a conexão com o banco
            MySqlConnection realizaConexaoBD = new MySqlConnection(conexoBD.ToString());

            try
            {
                realizaConexaoBD.Open();

                //Realiza consulta ao banco de dados de todos os registros da tabela
                MySqlCommand comando = realizaConexaoBD.CreateCommand();
                comando.CommandText = "SELECT * FROM produto";
                MySqlDataReader reader = comando.ExecuteReader();

                dataGridViewEditar.Rows.Clear();

                //Insere os dados no dataGrid
                while (reader.Read())
                {
                    DataGridViewRow row = (DataGridViewRow)dataGridViewEditar.Rows[0].Clone();
                    row.Cells[0].Value = reader.GetInt32(0);
                    row.Cells[1].Value = reader.GetInt32(1);
                    row.Cells[2].Value = reader.GetString(2);
                    row.Cells[3].Value = reader.GetString(3);
                    row.Cells[4].Value = reader.GetString(4);
                    row.Cells[5].Value = reader.GetString(5);
                    row.Cells[6].Value = reader.GetString(6);
                    row.Cells[7].Value = reader.GetString(7);
                    row.Cells[8].Value = reader.GetString(8);
                    dataGridViewEditar.Rows.Add(row);
                }

                realizaConexaoBD.Close();
            }

            catch (Exception ex)
            {
                //Informa que não foi possível realizar a conexão
                MessageBox.Show("Não foi possível realizar conexão");
                Console.WriteLine(ex.Message);
            }
        }

        private void dataGridViewEditar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //Insere os dados do dataGridView nos campos para edição
            txtBoxCod.Text = dataGridViewEditar.Rows[e.RowIndex].Cells["ColumnCodProduto"].FormattedValue.ToString();
            txtBoxCodInterno.Text = dataGridViewEditar.Rows[e.RowIndex].Cells["ColumncoInterno"].FormattedValue.ToString();
            comboBoxTipoProd.SelectedItem = dataGridViewEditar.Rows[e.RowIndex].Cells["ColumntipoProduto"].FormattedValue.ToString();
            txtBoxDesc.Text = dataGridViewEditar.Rows[e.RowIndex].Cells["ColumndescricaoItem"].FormattedValue.ToString();
            txtBoxPrecoVenda.Text = dataGridViewEditar.Rows[e.RowIndex].Cells["ColumnprecoVenda"].FormattedValue.ToString();
            txtBoxPrecoCusto.Text = dataGridViewEditar.Rows[e.RowIndex].Cells["ColumnprecoCusto"].FormattedValue.ToString();
            txtBoxFabricante.Text = dataGridViewEditar.Rows[e.RowIndex].Cells["ColumnrazaoSocialFab"].FormattedValue.ToString();
            txtLocalizacaoEstoque.Text = dataGridViewEditar.Rows[e.RowIndex].Cells["ColumndescLocalizacaoEst"].FormattedValue.ToString();
            comboBoxUniMed.SelectedItem = dataGridViewEditar.Rows[e.RowIndex].Cells["ColumnunidadeMedida"].FormattedValue.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Limpar os campos ao clicar no botão cancelar
            limparCampos();
        }
    }
}
